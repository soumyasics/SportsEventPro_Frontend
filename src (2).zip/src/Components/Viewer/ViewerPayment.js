import React from 'react'
import './ViewerPayment.css'

function ViewerPayment() {

    return (

        <div>

            

        </div>

    )

}

export default ViewerPayment
