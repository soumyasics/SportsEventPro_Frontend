import React from 'react'
import './TeamCoachLandingPage2.css'

function TeamCoachLandingPage2() {
  return (
    <div>
      <div class="container text-center">
  <div class="row">
    <div class="col">
<div className='TeamCoachLandingPage2-img'>
      </div>
    </div>
    <div class="col">
      
    </div>
    <div class="col">
      
    </div>
  </div>
</div>
    </div>
  )
}

export default TeamCoachLandingPage2
