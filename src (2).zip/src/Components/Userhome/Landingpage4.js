import React from 'react'
import './Landingpage4.css'

function Landingpage4() {
  return (
    <div className='landingpage4maindiv'>
      <div>
      <div className='landingpage4img'>
      </div>
        <div className='landingpage4head-1'>
            <h3>THE FIRST OF IT'S KIND SPORTS</h3>
            <h3>EVENT PRO PLATFORM</h3>
            <h3>JUST AMAZING WOW</h3>
        </div>
        <div className='landingpage4div1'>
            <h className='landingpage4head-2'>ITS NOT JUST SPORTS</h>
            </div>
            <div className='landingpage4div2'>
            <h1 className='landingpage4head-3'>START YOUR FIRST EVENT TODAY</h1>
        </div>
        </div>
       
    </div>
  )
}

export default Landingpage4
