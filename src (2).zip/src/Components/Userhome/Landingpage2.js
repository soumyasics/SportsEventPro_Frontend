import React from 'react'
import img from '../../Assets/Component 2.jpg'
import "./Landingpage2.css"
function Landingpage2() {
  return (
    <div>
        <div className='LandingPageDiv-1'>
        
<img src={img} className='LandingPageCenter-img'/>
</div>
    </div>
  )
}

export default Landingpage2 