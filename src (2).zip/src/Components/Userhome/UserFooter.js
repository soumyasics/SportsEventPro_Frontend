import React from "react";
import "./UserFooter.css";

function UserFooter() {
  return (
    <div>
      <div className="userfootermaindiv ">
      <div className='footerdiv-1'>
      </div>
      <div className="footerdiv-2">
        <div className="footerdot">
        </div>
      <h1 className="footerh1">Sports Event Pro</h1>
      
      </div>
      <div className="footerdiv-3">
      <div class="row">
  <div class="col-md-1">
  <button className='userfooterbutton-1 container'>Home</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-2'>About</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-3'>Contact</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-4'>Login</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-5'>Blog</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-6'>Success stories</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-7'>FAQs</button>
</div>
</div>
</div>
</div>

    </div>
  );
}

export default UserFooter;
