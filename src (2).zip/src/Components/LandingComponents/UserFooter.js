import React from "react";
import "./UserFooter.css";

function UserFooter() {
  return (
    <div>
      <div className="userfootermaindiv ">
      <div className='footerdiv-1 mt-2' >
      </div>
      <div className="footerdiv-2">
        <div className="footerdot">
        </div>
      <h1 className="footerh1">Sports Event Pro</h1>
      
      </div>
      <div className="footerdiv-3">
      <div class="row">
  <div class="col-md-1">
  <button className='userfooterbutton-1'>HOME</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-2'>ABOUT</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-3'>CONTACT</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-4'>LOGIN</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-5'>BLOG</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-6'>SUCCESS STORIES</button>
</div>
<div class="col-md-1">
<button className='userfooterbutton-7'>FAQs</button>
</div>
</div>
</div>
</div>
    </div>
  );
}

export default UserFooter;
