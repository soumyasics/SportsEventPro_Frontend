import React from 'react'

function AddEvent() {
  return (
    <div>AddEvent</div>
  )
}

export default AddEvent